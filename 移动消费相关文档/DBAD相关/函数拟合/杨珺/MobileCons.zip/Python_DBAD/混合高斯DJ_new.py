import os
import scipy
import numpy
from sklearn import mixture

os.chdir('F:/SelfTau/Project/MobileCons/Python_DBAD')
os.getcwd()
EXPID = 1
TYPEFEATURE = 1
fname = 'data'+str(EXPID)+'_'+str(TYPEFEATURE)+'.csv'
pfile = open(fname, 'r')
pline = pfile.readlines()

fields = [line.split(',') for line in pline]
user=[int(x[0]) for x in fields]
ts=[int(x[1]) for x in fields]
value=[float(x[2]) for x in fields]

#得到按user分段的数据，存储在x中
m=len(user)
i=0
x=[[] for x in range(max(user))]
for j in range(m):
	if user[j]==i+1:
		pass
	else:
		i=i+1
	x[i].append([user[j],ts[j],value[j]])

#用一个人的217组数据(存储在M中)求加速度的所有参数
def Parameters(x):
	breaks=range(0,1500*217+1,1500)
	n=len(breaks)-1
	M=[[] for M in range(n)]
	for i in range(len(y)):
		for j in range(n):
			if y[i][1] in range(breaks[j]+1,breaks[j+1]):
				M[j].append(y[i][2])
	m=numpy.array(M[0][1:end])
	EM=mixture.GMM(n_components=NUMBER_OF_GAUSSIAN, covariance_type='full')
	EM.fit(m.reshape(-1, 1))
	print(EM.converged_)
	weight = EM.weights_
	mean= EM.means_.tolist()
	cov = EM.covars_
	gaussian_params = weight, mean, cov
	gmm_em_result.extend(gaussian_params)
	#pretty_print_gmm(gmm_em_result)


def DJ(P,Q):
	n=len(P)
	m=len(Q)
	def p(x):
		h=0
		for i in range(1,n+1):
			s=1/sqrt(2*pi*P[i,2])
			h=h+P[i,3]*s*exp(-(x-P[i,1])^2/(2*P[i,2]))
			return(h)
	def q(x):
		h=0
		for i in range(1,m+1):
			s=1/sqrt(2*pi*Q[i,2])
			h=h+Q[i,3]*s*exp(-(x-Q[i,1])^2/(2*Q[i,2]))
			return(h)
	def dj(x):
		(p(x)-q(x))*log(p(x)/q(x))
	answer=integrate(dj,-30,30)
	return(answer)

