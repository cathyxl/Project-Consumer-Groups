import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class GroupingAccuracyAnalysis {
	public static void main(String args[]){
		ClassifyGroup classifyGroup=new ClassifyGroup();
		/**
		 * �˴�Ӧ�ø���adjacency.txt������·��
		 * �硰E:\\workshop\\codes_and_documents\\bdcc_gcsa_project\\svn_repository\\jbox2d-testbed\\frequency\\adjacency.txt��
		 */
		classifyGroup.start("adjacency.txt");
		//classifyGroup.printGroupList();
		GroupIDReader groupIDReader=new GroupIDReader();
		/**
		 * �˴�Ӧ�ø���groupid.txt������·��
		 */
		groupIDReader.read("groupid.txt");
		//groupIDReader.printGroupList();
		System.out.println("׼ȷ��ag: "+ClassifyGroup.analyzeAccuracy(groupIDReader.getGroupList(), classifyGroup.getGroupList()));
	}
}

class GroupIDReader{
	private String inputString;
	private String curLine;
	private ArrayList<ArrayList<String>> groupList=new ArrayList<ArrayList<String>>();
	/**
	 * ���ԭʼ����
	 * @return
	 */
	public ArrayList<ArrayList<String>> getGroupList(){
		return groupList;
	}
	/**
	 * ��ȡԭʼ�ķ�����Ϣ
	 * @param fileName
	 */
	public void read(String fileName){
		try {
			File file = new File(fileName);
			FileInputStream fileIn = new FileInputStream(file);
			int size = fileIn.available();
			byte[] buffer = new byte[size];
			fileIn.read(buffer);
			fileIn.close();
			inputString = new String(buffer, "UTF-8");
		} catch (FileNotFoundException e) {
			System.out.println("File " + fileName + " not found.");
			return;
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
		int newlineSymbolPos;
		while ((newlineSymbolPos = inputString.indexOf('\n')) != -1) {
			//ע�⣺�˴�newlineSymbolPos-1��Ϊ�˰ѡ�\r��Ҳɾȥ
			curLine = inputString.substring(0, newlineSymbolPos-1);
			inputString = inputString.substring(newlineSymbolPos + 1);
			addIntoGroupList(curLine);
		}
	}
	/**
	 * ����һ�е���Ϣ,�������ӵ�ԭʼ����������
	 * @param lineString
	 */
	private void addIntoGroupList(String lineString){
		int pid;
		int gid;
		ArrayList<String> group=new ArrayList<String>();
		String[] idWithGroup=lineString.split(" ");
		pid=Integer.parseInt(idWithGroup[0]);
		gid=Integer.parseInt(idWithGroup[1]);
		if(gid>groupList.size()-1){
			group.add(pid+"");
			groupList.add(group);
		}else{
			groupList.get(gid).add(pid+"");
		}
	}
	/**
	 * ��ӡ�������
	 */
	public void printGroupList(){
		int i=0;
		for(ArrayList<String> group:groupList){
			//if(group.size()>=2){
				System.out.print(i+": ");
				for(String peopleID:group){
					System.out.print(peopleID+" ");
				}
				System.out.println();
			//}
			i++;
		}
	}
}

class ClassifyGroup{
	private String inputString;
	private String curLine;
	private int lineNum=1;
	private ArrayList<ArrayList<String>> groupList;
	/**
	 * ���캯��
	 */
	public ClassifyGroup() {
		groupList=new ArrayList<ArrayList<String>>();
	}
	/**
	 * ��ʼ����
	 * @param fileName ���������ļ���
	 */
	public void start(String fileName){
		try {
			File file = new File(fileName);
			FileInputStream fileIn = new FileInputStream(file);
			int size = fileIn.available();
			byte[] buffer = new byte[size];
			fileIn.read(buffer);
			fileIn.close();
			inputString = new String(buffer, "UTF-8");
		} catch (FileNotFoundException e) {
			System.out.println("CMM Lexical Analyzer:  File " + fileName + " not found.");
			return;
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
		int newlineSymbolPos;
		while ((newlineSymbolPos = inputString.indexOf('\n')) != -1) {
			//ע�⣺�˴�newlineSymbolPos-1��Ϊ�˰ѡ�\r��Ҳɾȥ
			curLine = inputString.substring(0, newlineSymbolPos-1);
			inputString = inputString.substring(newlineSymbolPos + 1);
			analyzeSingleLine(curLine);
			lineNum++;
		}
	}
	
	private void analyzeSingleLine(String lineString){
		final double relThreshold=30;
		double relevancy;
		String[] releList=lineString.split(" ");
		boolean needNewGroup=true;
		ArrayList<String> temporaryGroup=new ArrayList<String>();
		
		_FOR_01_:
			for(ArrayList<String> group:groupList){
				for(String peopleID:group){
					if(lineNum==Integer.parseInt(peopleID)){
						needNewGroup=false;
						temporaryGroup=group;
						break _FOR_01_;
					}
				}
			}
		
		//
		if(needNewGroup){
			_FOR_02_:
				for(int i=lineNum-1,columnNum=lineNum;i<releList.length;i++){
					relevancy=Double.parseDouble(releList[i]);
					if(relevancy>=relThreshold){
						for(ArrayList<String> group:groupList){
							for(String peopleID:group){
								if(columnNum==Integer.parseInt(peopleID)){
									temporaryGroup=group;
									temporaryGroup.add(lineNum+"");
									needNewGroup=false;
									break _FOR_02_;
								}
							}
						}
					}
					columnNum++;
				}
		}
		
		if(needNewGroup)
			temporaryGroup.add(lineNum+"");
		
		for(int i=lineNum-1,columnNum=lineNum;i<releList.length;i++){
			relevancy=Double.parseDouble(releList[i]);
			if(relevancy>=relThreshold){
				boolean isExisting=false;
				for(String peopleID:temporaryGroup){
					if(columnNum==Integer.parseInt(peopleID)){
						isExisting=true;
						break;
					}
				}
				if(!isExisting)
					temporaryGroup.add(columnNum+"");
			}
			columnNum++;
		}
		
		if(needNewGroup)
			groupList.add(temporaryGroup);
	}
	
	public void printGroupList(){
		int i=0;
		for(ArrayList<String> group:groupList){
				System.out.print(i+": ");
				for(String peopleID:group){
					System.out.print(peopleID+" ");
				}
				System.out.println();
			i++;
		}
	}
	
	public ArrayList<ArrayList<String>> getGroupList(){
		return groupList;
	}
	/**
	 * ����ԭʼ����ͽ���������, �������龫ȷ��
	 * @param origin
	 * @param result
	 * @return
	 */
	public static double analyzeAccuracy(ArrayList<ArrayList<String>> origin,
			ArrayList<ArrayList<String>> result){
		final double errorRate=0.3;
		int hits=0;
		
		for(ArrayList<String> originGroup:origin){
			int[] a=new int[originGroup.size()];
			for(int i=0;i<originGroup.size();i++){
				_FOR_04_:
				for(int j=0;j<result.size();j++){
					for(String pid:result.get(j)){
						if(pid.equals(originGroup.get(i))){
							a[i]=j;
							break _FOR_04_;
						}
					}
				}
			}
			
			for(int i=1;i<a.length;i++){
				for(int j=0;j<i;j++){
					if(a[j]>a[j+1]){
						int temp;
						temp=a[j];
						a[j]=a[j+1];
						a[j+1]=temp;
					}
				}
			}
			
			int distance=0;
			int max=0;
			int s=0;
			for(int i=0;i<a.length;i++){
				if(a[s]==a[i]){
					distance++;
				}else{
					s=i;
					distance=1;
				}
				if(max<distance){
					max++;
				}
			}

			if((double)max/(double)a.length>(1.0-errorRate)){
				hits++;
			}
		}
		
		System.out.println("errorRate: "+errorRate);
		System.out.println("hits: "+hits);
		System.out.println("ԭʼ����: "+origin.size());
		System.out.println("׼ȷ��a: "+((double)hits/(double)origin.size()));
		System.out.println("�������: "+result.size());
		double bias=Math.abs((double)result.size()-(double)origin.size())/(double)origin.size();
		double accuracyRate=1.0;
		if(bias>errorRate){
			accuracyRate=1.0-(Math.abs((double)result.size()-(double)origin.size())-errorRate*(double)origin.size())/(double)result.size();
		}
		return (double)hits/(double)origin.size()*accuracyRate;
	}
}