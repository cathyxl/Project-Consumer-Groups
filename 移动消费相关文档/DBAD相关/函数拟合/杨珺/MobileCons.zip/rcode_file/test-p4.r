rm(list=ls())
#setwd("")
#example: setwd("D:/mobilecomsup/positioncode")
setwd("F:/SelfTau/Project/MobileCons/rcode_file")

# para setings

#群组个数
num.group=150

# 总人数
data=read.table("newPositionRecords.txt")
num.peop=ncol(data)/3

#程序重复运行的次数
num.simulation=20

#每个文件选取的记录条数
num.obs.each=200

s
gdata=function(num.obs.each)
{

  selected.ind=sample(1:nrow(data),num.obs.each,replace=F)
  selected.obs=data[selected.ind, ]
  
  return(selected.obs=selected.obs)
  
}
# 用层次聚类方法对每行记录做聚类处理
hcclust=function(selected.obs,num.group,num.peop)
{
  type.ind=rep(1:3,num.peop)
  real.group.ind=t(selected.obs[1,type.ind==1])
  
  relation=matrix(0,nrow=num.peop,ncol=num.peop)
  
  for(k in 1:nrow(selected.obs))
  {
    one.obs=selected.obs[k, ]
    x_coordinate=t(one.obs[type.ind==2])
    y_coordinate=t(one.obs[type.ind==3])
    xy=cbind(x_coordinate,y_coordinate)
    rownames(xy)=1:nrow(xy)
    colnames(xy)=c("x","y")
    
    hc0=hclust(dist(xy))
    hc=cutree(hc0,k=num.group)
    
    HCCLUST1=as.matrix(hc)%*%rep(1,num.peop)
    HCCLUST2=matrix(1,nrow=num.peop,ncol=1)%*%hc
    
    relation=relation+(HCCLUST1==HCCLUST2)  
    
  }
  relation=relation-diag(rep(nrow(selected.obs),num.peop))
  return(list(adjacent.matrix=relation,
              real.group.ind=real.group.ind))
}


ADJACENCY=matrix(0,nrow=num.peop,ncol=num.peop)

for(i in 1:num.simulation)
{
  selected.obs=gdata(num.obs.each=num.obs.each)
  hc.result=hcclust(selected.obs=selected.obs,num.group=num.group,
                    num.peop = num.peop)
  ADJACENCY=ADJACENCY+hc.result$adjacent.matrix
  if(i==1)
  {
    groupid=hc.result$real.group.ind
  }
  
}

ADJACENCY=ADJACENCY/num.simulation
Groupid=as.matrix(cbind(1:length(groupid),groupid))

# write.table(ADJACENCY,file="adjacency.txt",quote=F,row.name=F,col.names = F)
# write.table(Groupid,file="groupid.txt",quote=F,row.name=F,col.names = F)