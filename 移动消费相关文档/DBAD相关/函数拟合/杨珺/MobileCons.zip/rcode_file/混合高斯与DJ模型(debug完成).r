#�����ݷ���#
setwd('F:/SelfTau/Project/MobileCons/Python_DBAD')
rm(list=ls())
dat=read.csv("data1_1.csv")
x=dat[,1]
y=dat[,3]
m=length(x)
n=table(x)
x1=numeric(n[1])
x2=numeric(n[2])
x3=numeric(n[3])
x4=numeric(n[4])
x5=numeric(n[5])
x6=numeric(n[6])
x7=numeric(n[7])
x11=numeric(n[10])
x9=numeric(n[8])
x10=numeric(n[9])
for (i in 1:n[1])
{ 
if(x[i]==1)
x1[i]=y[i]
}
for (i in 1:n[1]+n[2]){
if(x[i]==2)
{x2[i-n[1]]=y[i]}
}
for (i in 1:n[1]+n[2]+n[3]){
if(x[i]==3)
{x3[i-n[1]-n[2]]=y[i]}
}
for (i in 1:n[1]+n[2]+n[3]+n[4]){
if(x[i]==4)
{x4[i-n[1]-n[2]-n[3]]=y[i]}
}
for (i in 1:n[1]+n[2]+n[3]+n[4]+n[5]){
if(x[i]==5)
{x5[i-n[1]-n[2]-n[3]-n[4]]=y[i]}
}
for (i in 1:n[1]+n[2]+n[3]+n[4]+n[5]+n[6]){
if(x[i]==6)
{x6[i-n[1]-n[2]-n[3]-n[4]-n[5]]=y[i]}
}
for (i in 1:n[1]+n[2]+n[3]+n[4]+n[5]+n[6]+n[7]){
if(x[i]==7)
{
x7[i-n[1]-n[2]-n[3]-n[4]-n[5]-n[6]]=y[i]
}
}
for (i in 1:n[1]+n[2]+n[3]+n[4]+n[5]+n[6]+n[7]+n[8]){
if(x[i]==9)
{x9[i-n[1]-n[2]-n[3]-n[4]-n[5]-n[6]-n[7]]=y[i]}
}
for (i in 1:n[1]+n[2]+n[3]+n[4]+n[5]+n[6]+n[7]+n[8]+n[9]){
if(x[i]==10)
{x10[i-n[1]-n[2]-n[3]-n[4]-n[5]-n[6]-n[7]-n[8]]=y[i]}
}
for (i in 1:m){
if(x[i]==11)
{x11[i-n[1]-n[2]-n[3]-n[4]-n[5]-n[6]-n[7]-n[8]-n[9]]=y[i]}
}


#����k-means�㷨���ֵ��EM�㷨����#
accel<-function(M,K,C){
m<-M
k<-K
accel=C
n=length(accel)
a=kmeans(accel,m)
alpha=(a$size)/n
sigma=(a$withinss)/a$size
miu=a$centers
prob <- matrix(rep(0,n*m),ncol=m)

for (step in 1:k){
     for (j in 1:m){
        prob[,j]<- sapply(accel,dnorm,miu[j],sigma[j])
      }
      sumprob <- rowSums(prob)
      prob<- prob/sumprob
 
      oldmiu <- miu
      oldsigma <- sigma
      oldalpha <- alpha
 
      for (j in 1:m){
        p1 <- sum(prob[ ,j])
        p2 <- sum(prob[ ,j]*accel)
        miu[j] <- p2/p1
        alpha[j] <- p1/n
        p3 <- sum(prob[ ,j]*(accel-miu[j])^2)
        sigma[j] <- sqrt(p3/p1)
       }
 
    epsilo <- 1e-5
	e_miu=sum(abs(miu-oldmiu))
	e_sigma=sum(abs(sigma-oldsigma))
	e_alpha=sum(abs(alpha-oldalpha))
    if( is.na(e_miu) | is.na(e_sigma) | is.na(e_alpha))
        break
    else if (e_miu <epsilo & e_sigma <epsilo & e_alpha <epsilo)
        break
}
d=matrix(c(miu,sigma,alpha),nrow=m)
return(d)
}


#JD����ʵ�� �ڣ�-20��20��֮��#
dj<-function(p,q){
p1=p[,1]
p2=p[,2]
p3=p[,3]
ps=p3/(sqrt(2*pi)*p2)
q1=q[,1]
q2=q[,2]
q3=q[,3]
qs=q3/(sqrt(2*pi)*q2)

P<-function(x)
{
ps[1]*exp(-(x-p1[1])^2/(2*p2[1]^2))+ps[2]*exp(-(x-p1[2])^2/(2*p2[2]^2))
}

Q<-function(x)
{
qs[1]*exp(-(x-q1[1])^2/(2*q2[1]^2))+qs[2]*exp(-(x-q1[2])^2/(2*q2[2]^2))
}

DJ<-function(x){
(P(x)-Q(x))*log(P(x)/Q(x))
}

return(integrate(DJ,-20,20))
}

p1=accel(2,50,x1)
p2=accel(2,50,x2)
p3=accel(2,50,x3)
p4=accel(2,50,x4)
p5=accel(2,50,x5)
p6=accel(2,50,x6)
p7=accel(2,50,x7)
p9=accel(2,50,x9)
p10=accel(2,50,x10)
p11=accel(2,50,x11)

dj(p1,p2)
dj(p1,p5)
dj(p1,p6)
dj(p1,p7)
dj(p1,p9)
dj(p1,p11)
dj(p5,p2)
dj(p6,p2)
dj(p7,p2)
dj(p9,p2)
dj(p11,p2)
dj(p5,p6)
dj(p5,p7)
dj(p5,p9)
dj(p5,p11)
dj(p6,p7)
dj(p6,p9)
dj(p6,p11)
dj(p7,p9)
dj(p7,p11)
dj(p9,p11)
