rm(list=ls())
orient=read.csv("F:/SelfTau/Project/MobileCons/Python_DBAD/data1_2.csv",head=F)
ang=orient[,3]/180*pi
orient=cbind(orient[-3],ang)
library(movMF)

###extract data from different person
per <- function(x){
    orient[which(orient[,1]==x),]
}

##��i���˵�n�����ڵĽǶ�
win <- function(i,n){
    angle=per(i)[,3]
    ind=per(i)[,2]
    l=which(ind>(1500*(n-1)))
    u=which(ind<(1500*n))
    win.ind=intersect(l,u)
    res=angle[win.ind]
    return(res)
}

##���Ƶ�i���˵�n�����ڵķֲ��Ĳ���
para <- function(i,n){
angle=win(i,n)
pts<- cbind(cos(angle), sin(angle))
est <- movMF(pts,1)
theta=est$thet
#VM�ֲ��ľ�ֵ
mu <- atan2(est$theta[,2], est$theta[,1])  #atan2(y, x) == atan(y/x)
#concentration parameter
kap <- sqrt(rowSums(est$theta^2))
#��ϸ���
alpha=est$alpha
return(list(pts=pts,theta=theta,mu=mu,kap=kap,alpha=alpha))
}




###cal DJ
#f1 <- function(i,n){
    theta=para(i,n)$theta
    kap=para(i,n)$kap
    alpha=para(i,n)$alpha
    mu=para(i,n)$mu
    x=para(i,n)$pts
   # return(x)
    dmovMF(x,theta,alpha)
}

DJ <- function(i,n,j,m){
    th1=para(i,n)$theta
    
    alpha1=para(i,n)$alpha
    
    f1<-function(x){
        xx<- cbind(cos(x), sin(x))
        dmovMF(xx,th1,alpha1)
    }
    
    th2=para(j,m)$theta
    
    alpha2=para(j,m)$alpha
    
    
    f2<-function(x){
        xx<- cbind(cos(x), sin(x))
        dmovMF(xx,th2,alpha2)
    }
    
    f <- function(x){
        (f1(x)-f2(x))*log(f1(x)/f2(x))
    }
    
    
    X=runif(10000,0,2*pi)
    D=2*pi*mean(f(X))
    
    return(D)
}


div=0
for (i in 1:10){
    d=DJ(1,i,2,i)
    div=c(div,d)
}




###����Ŷ�
###�ֳ�8�� �ֱ����pi
fp <- function(kap,theta,n=8){
        th=c(kap)*theta
        sam=rmovMF(10000,th,alpha)  ##�õ������ݺ�Ptsһ���ĸ�ʽ
        temp=matrix(sam,nrow=10000,ncol=2)
        rang=atan2(temp[,2],temp[,1])
        tabang=table(cut(rang,breaks=8))
        res=as.matrix(tabang)/10000
        return(res)
}

compare <- function(x,kap,theta){
    fp=fp(kap,theta,n=8)
    tabx=table(cut(x,breaks=8))  #xΪԭʼ����ת��Ϊrad֮��ĽǶ� ��win()�����
    tabx=c(tabx[c(5:8)],tabx[c(1:4)])
    x2=0
    for (i in 1:8){
        temp=(length(x)*as.numeric(fp[i,]))^2/as.numeric(tabx[i])
        #����ֵ
        p=length(x)*as.numeric(fp[i,])
        #ʵ��ֵ
        phat=as.numeric(tabx[i])
        temp=(p-phat)^2/p
        x2=x2+temp
    }
    res=x2
    return(res)
}

theta=para(1,1)$theta
kap=para(1,1)$kap
alpha=para(1,1)$alpha
mu=para(1,1)$mu
compare(win(1,1),kap,theta)
